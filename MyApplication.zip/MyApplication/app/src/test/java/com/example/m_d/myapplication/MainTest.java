package com.example.m_d.myapplication;

public class MainTest {
    public static void main(String [] args)
    {
        System.out.println("ok");
    }
}
