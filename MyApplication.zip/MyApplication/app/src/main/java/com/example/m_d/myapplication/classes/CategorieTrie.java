package com.example.m_d.myapplication.classes;

public enum CategorieTrie {
    DATESORTIE,
    DATEAJOUT,
    TITRE;
}
