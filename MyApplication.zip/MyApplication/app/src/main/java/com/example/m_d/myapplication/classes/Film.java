package com.example.m_d.myapplication.classes;

import java.util.Date;

public class Film implements Comparable<Film>{
    private String titre;
    private String reference;
    private Date dateSortie;
    private String categorie;
    private Date dateDajout;
    private String description;

    public Film(String titre, String reference, Date dateDajout, String description){
        this.titre = titre;
        this.reference = reference;
        this.dateDajout = dateDajout;
        this.description = description;
    }

    /**** Getter ****/

    public String getTitre(){
        return titre;
    }

    public String getReference(){
        return reference;
    }

    public Date getDateSortie(){
        return dateSortie;
    }

    public Date getDateDajout() {
        return dateDajout;
    }

    public String getCategorie(){
        return categorie;
    }


    /**** Setter ****/




    /**** Methode ****/

    @Override
    public boolean equals(Object obj) {
        Film film = (Film)obj;
        return this.titre.equals(film.getTitre()) && this.dateDajout.equals(((Film) obj).getDateDajout());
    }

    @Override
    public int hashCode() {
        return titre.hashCode() + dateDajout.hashCode();
    }

    /* Par défaut trie par date d'ajout (plus récent)*/
    public int compareTo(Film film) {
        return this.dateDajout.compareTo( film.getDateDajout() ) * -1;
    }

    public String toString(){
        return "Titre : "+titre+" Date ajout : "+this.dateDajout.getDay()+"/"+dateDajout.getMonth()+"/"+dateDajout.getYear();
    }
}
