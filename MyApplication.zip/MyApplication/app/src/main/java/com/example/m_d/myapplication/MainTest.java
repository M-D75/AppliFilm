package com.example.m_d.myapplication;

import com.example.m_d.myapplication.classes.CategorieTrie;
import com.example.m_d.myapplication.classes.Film;
import com.example.m_d.myapplication.classes.MonCompte;

import java.util.Date;

public class MainTest {
    public static void main(String [] args)
    {
        Film f = new Film("titre","ref",new Date(2017,2,3), "");
        Film f2 = new Film("titre2","ref2",new Date(2017,4,3),"");
        Film f3 = new Film("titre3","ref3",new Date(2016,2,3),"");
        Film f4 = new Film("titre4","ref4",new Date(2018,2,3),"");

        MonCompte mc = new MonCompte();
        mc.addFilm(f);
        mc.addFilm(f2);
        mc.addFilm(f3);
        mc.addFilm(f4);

        System.out.println("classement par date d'ajout "+mc.getFilmsVus());
        mc.setFilmsVus(mc.trieFilms(mc.getFilmsVus(), CategorieTrie.TITRE));
        System.out.println("classement par titre "+mc.getFilmsVus());


    }
}
