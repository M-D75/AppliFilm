package com.example.m_d.myapplication.classes;

public class Rubrique {
    private String titre;

    public Rubrique(String titre){
        this.titre = titre;
    }
}
