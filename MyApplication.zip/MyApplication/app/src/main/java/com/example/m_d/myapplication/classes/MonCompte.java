package com.example.m_d.myapplication.classes;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

public class MonCompte extends Rubrique {

    private Integer nombreAbonnes = 0;
    private Set<Film> filmsVus = new TreeSet<Film>();
    private Set<Object> articles;

    public MonCompte(){
        super("Mon Compte");
    }

    /**** Setter ****/

    public void  setNombreAbonnes(Integer nombreAbonnes){
        this.nombreAbonnes = nombreAbonnes;
    }

    public void setFilmsVus(Set<Film> filmsVus) {
        this.filmsVus = filmsVus;
    }

    /**** Getter ****/

    public Integer getNombreAbonnes(){
        return nombreAbonnes;
    }

    public Set<Film> getFilmsVus(){
        return filmsVus;
    }

    /**** Methode ****/

    /** Ajoute un film a l'ensemble filmVus **/
    public void addFilm(Film film){
        filmsVus.add(film);
    }

    /** Trie les films selon une categories **/
    public Set<Film> trieFilms(Set<Film> filmsVus, CategorieTrie categorieTrieTrie){
        Set<Film> ensFilms;
        Comparator<Film> comparator;

        switch (categorieTrieTrie){
            case DATEAJOUT: {//Par date d'ajout
               comparator = new Comparator<Film>() {
                    @Override
                    public int compare(Film f1, Film f2) {
                        return  f1.getDateDajout().compareTo(f2.getDateDajout());
                    }
                };
                break;
            }
            case DATESORTIE: {//Par date de sortie
                comparator = new Comparator<Film>() {
                    @Override
                    public int compare(Film f1, Film f2) {
                        return  f1.getDateSortie().compareTo(f2.getDateSortie());
                    }
                };
                break;
            }
            case TITRE: {//Par titre
                comparator = new Comparator<Film>() {
                    @Override
                    public int compare(Film f1, Film f2) {
                        return  f1.getTitre().compareTo(f2.getTitre());
                    }
                };
                break;
            }
            default:{
                comparator = new Comparator<Film>() {
                    @Override
                    public int compare(Film f1, Film f2) {
                        return  f1.getTitre().compareTo(f2.getTitre());
                    }
                };
            }
        }

        ensFilms = new TreeSet<Film>(comparator);
        ensFilms.addAll(filmsVus);
        return ensFilms;
    }


}
